<?php


$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "contacts_management_system";

// connect to mysql
$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysql select query

$query = "SELECT id,full_name, number FROM `contacts";
// result for method one
$result1 = mysqli_query($connect, $query);

// result for method two 
$result2 = mysqli_query($connect, $query);

$dataRow = "";

while($row2 = mysqli_fetch_array($result2))
{
    $dataRow = $dataRow."<tr><td>$row2[0]</td><td>$row2[1]</td><td>$row2[2]</td></tr>";
}
if (isset($_POST['editc'])) {
		header('location: edit.php');
	}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>

<body>

<form action="all.php" method="post" class="list-form">

  <h2>CONTACTS LIST</h2>      

   
        <table style="table-layout: fixed ; width: 100%;">

            <tr>
                <th>S.NO</th>
                <th>Full Name</th>
                <th>Phone Number</th>
				<th>ACTION</th>
                
            </tr>

            <?php while($row1 = mysqli_fetch_array($result1)):;?>
            <tr>
                <td><?php echo $row1[0];?></td>
                <td><?php echo $row1[1];?></td>
                <td><?php echo $row1[2];?></td>
				<td><a href="rud.php?id=$data[id]" style="text-decoration: none"><input type="submit" value="edit"  name="editc"/></a></td>
                
            </tr>
            <?php endwhile;?>

        </table>

	 

  

    </form>

    <script type="text/javascript">

   

</body>

</html>

