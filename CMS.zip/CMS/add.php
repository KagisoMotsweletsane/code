

<!DOCTYPE html>
<html lang="en">
<head>
<body>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>

<body>

<form action="process.php" method="post" class="add-form">

  <h2>ADD CONTACT</h2>       

    <div class="txtb">
	<label>full name</label>
    <input type="text" name="full_name" required>

   
    </div>

    <div class="txtb">
	<label>profession</label>
    <input type="text" name="profession"  required>
</div>

    <div class="txtb">
	<label>email address</label>
    <input type="text" name="email"  required>
	</div>

    <div class="txtb">
	<label>mobile number</label>
    <input type="text" name="number"  required>
	</div>

    <div class="txtb">
	<label>city</label>
    <input type="text" name="city"  required>
	</div>

    <div class="txtb">
	<label>address</label>
    <input type="text" name="address"  required>
    

    </div>

   

    <input type="submit" name="add" value="add" class='btn'> 

   

  

    </form>

    <script type="text/javascript">


</body>

</html>