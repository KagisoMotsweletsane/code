<?php


$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "contacts_management_system";
$update = true;

// connect to mysql
$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysql select query

$query = "SELECT full_name FROM `contacts";


// result for method one
$result1 = mysqli_query($connect, $query);

$result2 = mysqli_query($connect, $query);


$options = "";


while($row2 = mysqli_fetch_array($result2))
{
    $options = $options."<option>$row2[0]</option>";
}
	if (isset($_GET['editc'])) {
		$id = $_GET['editc'];
		$update = true;
		$record = mysqli_query($db, "SELECT * FROM contacts WHERE id=$id");

		if (count($record) == 1 ) {
			mysqli_fetch_array($record);
			$name = $_POST['name'];
			$profession = $_POST['profession'];
			$email =$_POST['email'];
			$number = $_POST['number'];
			$city = $_POST['city'];
			$address = $_POST['address'];
		}
	}
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>

<body>

<form action="process.php" method="post" class="edit-form">

  <h2>EDIT CONTACTS</h2>      

    <div class="txtb">
	<label>full name</label>
    <input type="text" name="full_name" required>

   
    </div>
    <div class="txtb">
	<label>profession</label>
    <input type="text" name="profession"  required>
</div>

    <div class="txtb">
	<label>email address</label>
    <input type="text" name="email"  required>
	</div>

    <div class="txtb">
	<label>mobile number</label>
    <input type="text" name="number"  required>
	</div>

    <div class="txtb">
	<label>city</label>
    <input type="text" name="city"  required>
	</div>

    <div class="txtb">
	<label>address</label>
    <input type="text" name="address"  required>
    

    </div>

   

    <input type="submit" name="update" value="update" class='btn'> 

   

  

    </form>

    <script type="text/javascript">

  
</body>

</html>