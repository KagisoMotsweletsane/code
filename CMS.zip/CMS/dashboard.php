<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>

<body>

<form action="process.php" method="post" class="dashboard-form">

  <h2>DASHBOARD</h2>       

    <div>
	
<input type="submit" name="add" value="Add contact" class='btn'> 
   
    </div>

    <div>
	
<input type="submit" name="list" value="contacts list" class='btn'> 
    

    </div>
	<div>
   


<input type="submit" name="search" value="search contacts" class='btn'> 
    </div>
	<div>
	<input type="submit" name="all" value="all contacts" class='btn'> 
</div>
<div>
<input type="submit" name="business" value="business contacts" class='btn'> 
</div>
<div>
<input type="submit" name="private" value="private contacts" class='btn'> 
</div>
<div>
<input type="submit" name="logout" value="logout" class='btn'> 
<div>
    </form>

    <script type="text/javascript">


</body>

</html>
