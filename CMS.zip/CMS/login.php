<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'contacts_management_system');
	
	$username = "";
	$password = "";
	
	if (isset($_POST['login']))
{
$username =$_POST['username'];
$password = $_POST['password'];
if($username=="Myuser" && $password=="SA1@123")
{
	echo("logged in");
}
else{
	echo ("not logged in");
}
header('location: dashboard.php');

}
?>

<!DOCTYPE html>

<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>LOGIN</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>

<body>

<form action="login.php" method="post" class="login-form">

  <h2>CMS||LOGIN</h2>       

    <div class="txtb">
	<label>Username</label>
    <input type="text" name="username" required>

   
    </div>

    <div class="txtb">
	<label>Password</label>
    <input type="password" name="password"  required>

    

    </div>

   

    <input type="submit" name="login" value="login" class='btn'> 

   

    <div class="ca">Don't remember password? <a href="signup.php">Click here</a></div>

    </form>

    <script type="text/javascript">

    
</body>

</html>

