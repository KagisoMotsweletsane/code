<?
$result = mysql_query("SELECT full_name FROM contacts");
 while ($row = mysql_fetch_assoc($result)) {
echo "<div id='link' onClick='addText(\"".$row['full_name']."\");'>" . $row['full_name'] . "</div>";  
 }


  ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>
<body>
<form action="search.php" method="GET" class="dashboard-form">

  <h2>SEARCH</h2>       

    <div>
		<input type="text" name="search" style="width: 100%;"/>
		<input type="submit" value="Search" class="btn"  style="width: 80%;"/>
	</form>
</body>
</html>