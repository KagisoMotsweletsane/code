<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'contacts_management_system');

	// initialize variables
	$full_name = "";
	$profession = "";
	$email = "";
	$number = "";
	$city = "";
	$address = "";
	$username = "";
	$password = "";
	$id = 0;
	$update = true;
	$result = "";

	if (isset($_POST['add'])) {
		$full_name = $_POST['full_name'];
		$profession = $_POST['profession'];
		$email =$_POST['email'];
		$number = $_POST['number'];
		$city = $_POST['city'];
		$address = $_POST['address'];

		mysqli_query($db, "INSERT INTO contacts (id, full_name, profession, email, number, city, address) VALUES ('$id', '$full_name', '$profession', '$email', '$number', '$city', '$address')"); 
		$_SESSION['message'] = "contact saved"; 
		header('location: add.php');
	}
	if (isset($_POST['update'])) {
		$full_name = $_POST['full_name'];
		$profession = $_POST['profession'];
		$email =$_POST['email'];
		$number = $_POST['number'];
		$city = $_POST['city'];
		$address = $_POST['address'];

		mysqli_query($db, "UPDATE info SET full_name='$full_name', profession='$profession', email='$email', number='$number', city='$city', address='$address' WHERE id=$id");
		$_SESSION['message'] = "contact updated"; 
		header('location: edit.php');
	}
	
	if (isset($_POST['add'])) {
		header('location: add.php');
	}
	if (isset($_POST['list'])) {
		header('location: list.php');
	}
	if (isset($_POST['all'])) {
		header('location: all.php');
	}
	if (isset($_POST['private'])) {
		header('location: private.php');
	}
	if (isset($_POST['business'])) {
		header('location: business.php');
	}
	if (isset($_POST['search'])) {
		header('location: search.php');
	}
	if (isset($_POST['edit'])) {
		header('location: edit.php');
	}
	
	

