/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package systems.development.pkg2.fa2;

/**
 *
 * @author guvaine
 */
public class SystemsDevelopment2FA2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        frmMain frmM = new frmMain();
        frmM.show();
    }
    
}
