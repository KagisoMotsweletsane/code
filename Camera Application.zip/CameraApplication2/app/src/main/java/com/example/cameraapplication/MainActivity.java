package com.example.cameraapplication;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.graphics.Camera;
import android.graphics.SurfaceTexture;
import android.hardware.camera2.CameraAccessException;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraDevice;
import android.hardware.camera2.CameraManager;
import android.hardware.camera2.CaptureRequest;
import android.hardware.camera2.params.StreamConfigurationMap;
import android.media.ImageReader;
import android.os.Handler;
import android.os.HandlerThread;
import android.support.v4.app.ActivityCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.SparseIntArray;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private Button btnCaptureImage;
    private TextureView textureView;

    //check state orientation of output image
    private static final SparseIntArray ORIENTATION = new SparseIntArray();
    static {
        ORIENTATION.append(Surface.ROTATION_0,90);
        ORIENTATION.append(Surface.ROTATION_90,0);
        ORIENTATION.append(Surface.ROTATION_180,270);
        ORIENTATION.append(Surface.ROTATION_270,180);
    }

    private String cameraId
            private CameraDevice;
    private CameraCaptureSession cameraCaptureSession;
private CaptureRequest.Builder captureRequestBuilder;
private size imageDimension;
private ImageReader imageReader;

//Save to FILE
    private File file;
    private static final int REQUEST_CAMERA_PERMISSION = 200;
    private boolean mFlashSupported;
    private Handler mBackgroundHandler;
    private HandlerThread mBackgroundThread;

    CameraDevice.StateCallback stateCallBack = new CameraDevice.StateCallback() {
        @Override
        public void onOpened(@androidx.annotation.NonNull CameraDevice camera) {
        }

        @Override
        public void onDisconnected(@androidx.annotation.NonNull CameraDevice camera) {

        }

        @Override
        public void onError(@androidx.annotation.NonNull CameraDevice camera, int error) {

        }
    }

    {}
        @Override
        public void onOpened(@androidx.annotation.NonNull CameraDevice camera) {
            cameraDevice = camera;
            createCameraPreview();
        }

        @Override
        public void onDisconnected(@androidx.annotation.NonNull CameraDevice camera) {
cameraDevice.close();
        }
 0
        @Override
        public void onError(@androidx.annotation.NonNull CameraDevice camera, int error) {
            cameraDevice.close();
            cameraDevice=null;
        }

        }
    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        textureView = (TextureView) findViewById(R.id.textureView);
        //from Java 1.4 , you can use keyboard 'assert' to check expression true or false
        assert textureView != null;
        textureView.setSurfaceTextureListener(new TextureView.SurfaceTextureListener() {...});
            btnCaptureImage = (button)findViewById(R.id.btnCaptureImage);
            btnCaptureImage.setOnClickListener(new View.onClickListener() {
            @Override
            public void onClick(View view) {
                takePicture();
                )
            });
            }

            private void takePicture() {
        }

        private void openCamera() {
        }
            public void onSurfaceTextureAvailable(SurfaceTexture surfaceTexture, int i, int i1) {
                openCamera();
            }

            @Override
            public void onSurfaceTextureSizeChanged(SurfaceTexture surfaceTexture, int i, int i1) {

            }

            @Override
            public boolean onSurfaceTextureDestroyed(SurfaceTexture suraceTexture) {
                return false;
            }

            @Override
            public void onSurfaceTextureUpdated(SurfaceTexture surfaceTexture) {

            }
        }

        private void takePicture() {
        if(cameraDevice == null)
            return;
        CameraManager manager = (CameraManager)getSystemService(context.CAMERA_SERVICE);
        try{
            CameraCharacteristics characteristics = manager.getCameraCharacteristics(cameraDevice.getId{));
Size[] jpegSizes = null;
if (characteristics 1= null)
    jpegSizes = characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP).getOutputSizes(ImageFormat.JPEG);
//Capture image with custom size
                int width = 640;
                int height = 480;
                if (jpegSizes != null)
        }
        }

    private void openCamera(){
        CameraManager manager=(CameraManager)getSystemService(Context.CAMERA_SERVICE);
        try{
        cameraId=manager.getCameraIdList()[0];
        CameraCharacteristics characteristics=manager.getCameraCharacteristics(cameraId);
        StreamConfigurationMap map=characteristics.get(CameraCharacteristics.SCALER_STREAM_CONFIGURATION_MAP);
        assert map!=null;
        imageDimension=map.getOutputSizes(SurfaceTexture.class)[0];
//check realtime permission if run higher than API level 23
        if(ActivityCompact.checkSelfPermission(context:this,Manifest.permission.CAMERA)!=PackageManager.PERMISSION_GRANTED)
        {
        Activity.Compact.requestPermissions(activity.this,new String[]{
        Manifest.permission.CAMERA,
        Manifest.permission.WRITE_EXTERNAL_STORAGE
        },REQUEST_CAMERA_PERMISSION);
        return;
        }
        manager.openCamera(cameraId,stateCallBack,handler:null);

        }catch(CameraAccessException e){
        e.printStackTrace();
        }
        }
        }