<?php
echo '<table id="viewAll">';
            echo '<tr>';
            echo '<th>Product</th>';
            echo '<th>Status</th>';
            echo '<th>Summary</th>';
            echo '<th>Created</th>';
            echo '<th>Updated</th>';
            echo '<th>Edit</th>';

            echo '</tr>';


            while ($data=mysqli_fetch_array($result)){

            echo '<tr align="center">

            <td>'.$data['product'].'</td>
            <td>'.$data['status'].'</td>
            <td align="left">'.$data['summary'].'</td>
            <td>'.$data['created'].'</td>
            <td >'.$data['updated'].'</td>';

            echo "<td><a href=\"editForm.php?id=$data[id]\" style=\"text-decoration: none\"><input type=\"submit\" value=\"Edit\" /></a></td>";

            echo '</tr>';


                


            }



echo '</table>';
?>