<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>

<body>

<form action="process.php" method="post" class="add-form">

  <h2>ADD PATIENT</h2>     
	
		<div class="txtb">
			<label>Full Name</label>
			<input type="text" name="fullname" value="">
			</div>
		<div class="txtb">
			<label>Surname</label>
			<input type="text" name="surname" value="">
			</div>
		<div class="txtb">
			<label>ID Number</label>
			<input type="text" name="id_number" value="">
			</div>
		<div class="txtb">
			<label>Contact number</label>
			<input type="text" name="phone_number" value="">
		</div>
		<div class="txtb">
			<label>Address</label>
			<input type="text" name="address" value="">
		</div>
    <input type="submit" name="add" value="ADD" class='btn'> 
    </form>

    <script type="text/javascript">

    
</body>

</html>