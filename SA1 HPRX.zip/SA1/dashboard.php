<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Dashboard</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>

<body>

<form action="process.php" method="post" class="dashboard-form">

  <h2>HOME PAGE</h2>     
	
		<div>
			<input type="submit" name="list" value="PATIENTS LIST" class='btn'>
		</div>
		<input type="submit" name="edit" value="DELETE AND UPUDATE" class='btn'>
		</div>
    <input type="submit" name="add" value="ADD" class='btn'> 
    </form>

    <script type="text/javascript">

    
</body>

</html>