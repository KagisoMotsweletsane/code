<?php 
	session_start();
	$db = mysqli_connect('localhost', 'root', '', 'clinic');

	// initialize variables
	$fullname = "";
	$surname = "";
	$id_number = "";
	$phone_number = "";
	$address = "";
	$id = 0;
	$update = false;
	$username = "";
	$password = "";

	if (isset($_POST['add'])) {
		$fullname = $_POST['fullname'];
		$surname = $_POST['surname'];
		$id_number = $_POST['id_number'];
		$phone_number = $_POST['phone_number'];
		$address = $_POST['address'];

		mysqli_query($db, "INSERT INTO info (fullname, surname, id_number, phone_number, address) VALUES ('$fullname', '$surname', '$id_number', '$phone_number', '$address')"); 
		$_SESSION['message'] = "patient added"; 
		header('location: add.php');

if (isset($_POST['add'])) {
		header('location: add.php');
	}
	if (isset($_POST['list'])) {
		header('location: list.php');
	}
	if (isset($_POST['edit'])) {
		header('location: rud.php');
	}
	if (isset($_POST['login']))
{
$username =$_POST['username'];
$password = $_POST['password'];
if ($username == "" || $password == "")
$error = 'Not all fields were entered';
else
{
mysqli_query($db, "SELECT username,password FROM login WHERE username='$username' AND password='$password'");

$_SESSION['username'] = $username;
$_SESSION['password'] = $password;
header('location: dashboard.php');

}
}
