
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>login</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>

<body>

<form action="process.php" method="post" class="login-form">

  <h2>LOGIN</h2>       

    <div class="txtb">
	<label>Username</label>
    <input type="text" name="username" required>

   
    </div>

    <div class="txtb">
	<label>Password</label>
    <input type="password" name="password"  required>
    </div>
    <input type="submit" name="login" value="login" class='btn'> 

   

    <div class="ca">Don't remember password? <a href="signup.php">Click here</a></div>

    </form>

    <script type="text/javascript">

    
</body>

</html>

