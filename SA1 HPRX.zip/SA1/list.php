<?php


$hostname = "localhost";
$username = "root";
$password = "";
$databaseName = "clinic";

// connect to mysql
$connect = mysqli_connect($hostname, $username, $password, $databaseName);

// mysql select query

$query = "SELECT * FROM `info";


// result for method one
$result1 = mysqli_query($connect, $query);

// result for method two 
$result2 = mysqli_query($connect, $query);

$dataRow = "";

while($row2 = mysqli_fetch_array($result2))
{
    $dataRow = $dataRow."<tr><td>$row2[0]</td><td>$row2[1]</td><td>$row2[2]</td><td>$row2[3]</td><td>$row2[4]</td><td>$row2[5]</td></tr>";
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">

    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Document</title>

    <link rel="stylesheet" href="style.css">
	
<title> </title>
	<link rel="stylesheet" a href="css\style.css">
	<link rel="stylesheet" a href="css\font-awesome.min.css">
</head>

<body>

<form action="list.php" method="post" class="add-form">

  <h2>PATIENT LIST</h2>      

   
        <table style="table-layout: fixed ; width: 100%;">

            <tr>
                <th>ID</th>
                <th>Full Name</th>
				<th>Surname</th>
				<th>ID NO</th>
				<th>Phone NO</th>
                <th>Address</th>
                
            </tr>

            <?php while($row1 = mysqli_fetch_array($result1)):;?>
            <tr>
                <td><?php echo $row1[0];?></td>
                <td><?php echo $row1[1];?></td>
                <td><?php echo $row1[2];?></td>
				<td><?php echo $row1[3];?></td>
				<td><?php echo $row1[4];?></td>
				<td><?php echo $row1[5];?></td>
                
            </tr>
            <?php endwhile;?>

        </table>

	 

  

    </form>

    <script type="text/javascript">

   

</body>

</html>

