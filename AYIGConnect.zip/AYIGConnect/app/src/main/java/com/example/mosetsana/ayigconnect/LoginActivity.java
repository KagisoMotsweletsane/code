
package com.example.mosetsana.ayigconnect;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    EditText mTextUsername;
    EditText mTextPassword;
    Button mButtonLogin;
    TextView mTextViewRegister;
    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        mTextUsername =  findViewById(R.id.edittext_username);
        mTextPassword =  findViewById(R.id.edittext_password);
        mButtonLogin =  findViewById(R.id.button_login);
        mTextViewRegister = findViewById(R.id.textview_register);
        databaseHelper = new DatabaseHelper(this);

        mButtonLogin.setOnClickListener(new View.OnClickListener(){

            @Override
            public void onClick(View view) {
                String Username = mTextUsername.getText().toString();
              String password = mTextPassword.getText().toString();

              if(databaseHelper.isLoginValid(Username, password)){
                  Intent intent = new Intent(LoginActivity.this, AdminActivity.class);
                  startActivity(intent);
                  Toast.makeText(LoginActivity.this, "Login Successful", Toast.LENGTH_SHORT).show();
              }
              else{
                  Toast.makeText(LoginActivity.this, "Invalid username or password", Toast.LENGTH_SHORT).show();
              }
            }

        });
        mTextViewRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginActivity.this, RegisterActivity.class);
                startActivity(intent);
            }
        });


        }
    }



