package com.example.mosetsana.ayigconnect;

import android.content.ContentValues;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterActivity extends AppCompatActivity {
    EditText mTextUsername;
    EditText mTextPassword;
    EditText mTextConfirmPassword;
    Button mButtonRegister;
    TextView mTextViewLogin;
    DatabaseHelper databaseHelper;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        mTextUsername = (EditText) findViewById(R.id.edittext_username);
        mTextPassword = (EditText) findViewById(R.id.edittext_password);
        mTextConfirmPassword = (EditText) findViewById(R.id.edittext_confirm_password);
        mButtonRegister = (Button) findViewById(R.id.button_Register);
        mTextViewLogin = (TextView) findViewById(R.id.textview_register);
        databaseHelper = new DatabaseHelper(this);

        mButtonRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String usernameValue = mTextUsername.getText().toString();
                String password = mTextPassword.getText().toString();
                String confirm_password = mTextConfirmPassword.getText().toString();

                if (usernameValue.length()>1){
                    ContentValues contentValues = new ContentValues();
                    contentValues.put("username", usernameValue);
                    contentValues.put("password", password);
                    contentValues.put("confirmpassword", confirm_password.matches("password"));

                    databaseHelper.insertUser(contentValues);
                    Toast.makeText(RegisterActivity.this, "user registered", Toast.LENGTH_SHORT).show();
                }else{
                    Toast.makeText(RegisterActivity.this, "enter values", Toast.LENGTH_SHORT).show();
                }
            }

            });
    }
    }





